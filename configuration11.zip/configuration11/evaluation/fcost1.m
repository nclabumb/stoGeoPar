%EC, geocost, EC_mean, geocost_mean column mapping
%kappa = 1, gamma = 2, a = 3, rnd = 4, gbr/rnd = 5

%EC_KM_MT column mapping
%kappa = 1, gamma = 2, a = 3, km = 4, mt = 5


EC = csvread("EC_rd_cost_allkappa_M100.csv"); % kappa(1), gamma (2), 
geocost = csvread("geo_rd_cost_allkappa_M100.csv");

EC_km_mt = csvread("EC_KM_MT_cost_M100.csv");
geocost_km_mt = csvread("geo_KM_MT_cost_M100.csv");

ECmean = csvread("EC_rd_BRMeancost_allkappa_M100.csv"); % kappa(1), gamma (2), 
geocostmean = csvread("geo_rd_BRmean_cost_allkappa_M100.csv");
%X => a
%Y => ec + geo cost



a = 0:0.1:1;
%row_start = 1 ; %kappa=0.7

%row_start = 56 ; %kappa=1.0
row_start = 111; %kappa = 1.3

num_row_gap = 10;

max_geo = 670470; %kmean_cost_1cluster % max(max(geocost(1:7, :))); % to scale

num_gamma = 5;
y_km = zeros(1,num_gamma);
y_rd = zeros(1,num_gamma);

%for i = 1:num_gamma
    
%    y_km(i) = EC_km_mt(row_start + (i -1) * num_row_gap + (i-1),4) + ...
%                geocost_km_mt(row_start + (i -1) * num_row_gap + (i-1),4)/max_geo;
%    y_mt(i) = EC_km_mt(row_start + (i -1) * num_row_gap + (i-1),5)+ ...
%                geocost_km_mt(row_start + (i -1) * num_row_gap + (i-1),5)/max_geo;
    
%end


g1 = EC(row_start                       : row_start +     num_row_gap,     5); % gamma = .1
g3 = EC(row_start +     num_row_gap + 1 : row_start + 2 * num_row_gap + 1, 5); % gamma = .3
g5 = EC(row_start + 2 * num_row_gap + 2 : row_start + 3 * num_row_gap + 2, 5); % gamma = .5
g7 = EC(row_start + 3 * num_row_gap + 3 : row_start + 4 * num_row_gap + 3, 5); % gamma = .7
g9 = EC(row_start + 4 * num_row_gap + 4 : row_start + 5 * num_row_gap + 4, 5); % gamma = .9

g1 = transpose(a) .* g1 + (1-transpose(a)) .* geocost(row_start                       : row_start +     num_row_gap,     5)/max_geo; % gamma = .1
g3 = transpose(a) .* g3 + (1-transpose(a)) .* geocost(row_start +     num_row_gap + 1 : row_start + 2 * num_row_gap + 1, 5)/max_geo; % gamma = .3
g5 = transpose(a) .* g5 + (1-transpose(a)) .* geocost(row_start + 2 * num_row_gap + 2 : row_start + 3 * num_row_gap + 2, 5)/max_geo; % gamma = .5
g7 = transpose(a) .* g7 + (1-transpose(a)) .* geocost(row_start + 3 * num_row_gap + 3 : row_start + 4 * num_row_gap + 3, 5)/max_geo; % gamma = .7
g9 = transpose(a) .* g9 + (1-transpose(a)) .* geocost(row_start + 4 * num_row_gap + 4 : row_start + 5 * num_row_gap + 4, 5)/max_geo; % gamma = .9


g1mean = ECmean(row_start                       : row_start +     num_row_gap,     5); % gamma = .1
g3mean = ECmean(row_start +     num_row_gap + 1 : row_start + 2 * num_row_gap + 1, 5); % gamma = .3
g5mean = ECmean(row_start + 2 * num_row_gap + 2 : row_start + 3 * num_row_gap + 2, 5); % gamma = .5
g7mean = ECmean(row_start + 3 * num_row_gap + 3 : row_start + 4 * num_row_gap + 3, 5); % gamma = .7
g9mean = ECmean(row_start + 4 * num_row_gap + 4 : row_start + 5 * num_row_gap + 4, 5); % gamma = .9

g1mean = transpose(a) .* g1mean + (1-transpose(a)) .* geocostmean(row_start                       : row_start +     num_row_gap,     5)/max_geo; % gamma = .1
g3mean = transpose(a) .* g3mean + (1-transpose(a)) .* geocostmean(row_start +     num_row_gap + 1 : row_start + 2 * num_row_gap + 1, 5)/max_geo; % gamma = .3
g5mean = transpose(a) .* g5mean + (1-transpose(a)) .* geocostmean(row_start + 2 * num_row_gap + 2 : row_start + 3 * num_row_gap + 2, 5)/max_geo; % gamma = .5
g7mean = transpose(a) .* g7mean + (1-transpose(a)) .* geocostmean(row_start + 3 * num_row_gap + 3 : row_start + 4 * num_row_gap + 3, 5)/max_geo; % gamma = .7
g9mean = transpose(a) .* g9mean + (1-transpose(a)) .* geocostmean(row_start + 4 * num_row_gap + 4 : row_start + 5 * num_row_gap + 4, 5)/max_geo; % gamma = .9




%aplot = [1 2 4 6 8 10 11]; % 0, .1, .3, .5, .7, .9, 1
% ya mapping 
%row 1 = a0, 2 = a0.1, 3 = a0.2, .... 10 = a0.9, 11 = a1

gamma = 0.1:0.2:0.9;
ya = [g1, g3, g5, g7, g9];
yamean = [g1mean, g3mean, g5mean, g7mean, g9mean];
yaplot = [3 5 7 9];

num_a = size(yaplot,2);

lg = {'BR/Gauss', 'BR/Gauss', 'BR/Gauss', 'BR/Gauss', 'BR/Gauss', ...
    'BR/Gauss', 'BR/Gauss', 'BR/Gauss', 'BR/Gauss', 'BR/Gauss', ...
    'BR/Gauss'};
lgmean = {'BR/Mean'};

marker = '*+odsx.ph^v';%{'*', '+', 'o', 'diamond', 'square', 'x', '.', 'pentagram', 'hexagram', '^', 'v' };
c = [1 0 0
    0 1 0
    1 1 0
    0 0.4470 0.7410
    0.8500 0.3250 0.0980
    0.9290 0.6940 0.1250
    0.4940 0.1840 0.5560
    0.4660 0.6740 0.1880
    0.3010 0.7450 0.9330
    0.6350 0.0780 0.1840];

num_fig = 4; %kmean, metis and BR/Gauss, BR/Mean for each a



%for fig = 1:num_fig
    for k = 1:num_a
        %figure;
        figure('Renderer', 'painters', 'Position', [10 10 900 600]);
        aplot = (yaplot(k) - 1) * 0.1;
        lgshow = { 'kMeans','Rand'};

        for i = 1:num_gamma
    
            y_km(i) = aplot * EC_km_mt(row_start + (i -1) * num_row_gap + (i-1),4) + ...
                        (1-aplot) * geocost_km_mt(row_start + (i -1) * num_row_gap + (i-1),4)/max_geo;
            y_rd(i) = aplot * EC(row_start + (i -1) * num_row_gap + (i-1),4)+ ...
                        (1-aplot) * geocost(row_start + (i -1) * num_row_gap + (i-1),4)/max_geo;

        end
        
        pkm= plot(gamma, y_km, 'LineWidth', 2); %, 'Color', [0 0 1]%km, blue
        pkm.Marker = '+';
        pkm.MarkerSize = 20;%'MarkerSize',10,...
        hold on;    

        prd= plot(gamma, y_rd, 'LineWidth', 2); %rnd, geen
        prd.Marker = '*';
        prd.MarkerSize = 20;
        hold on;

        p= plot(gamma, ya(yaplot(k), :), 'LineWidth', 2); %BR/Gauss, red
        p.Marker = 'd';%marker(1,k);
        %p.Color = [1 0 0];%c(i, :);
        p.MarkerSize = 20;
        lgshow(3) = lg(yaplot(k));
        
        pmean= plot(gamma, yamean(yaplot(k), :), 'LineWidth', 2); %BR/mean, yellow
        pmean.Marker = 's';%marker(1,k);
        %pmean.Color = [0 1 1];%c(i, :);
        pmean.MarkerSize = 20;
        lgshow(4) = lgmean(1);
        
        
        legend (lgshow, 'Location', 'Best');
        title ("kappa = 1.3", 'FontSize', 50);
        xlabel("gamma", 'FontSize', 50, 'FontWeight', 'bold');
        ylabel ('Objective Cost','FontSize',50,'FontWeight', 'bold');
        ylim([0 inf]);
        
        %axis([0.1 0.9 0 0.9]);
        set(gca,'FontSize',30, 'box', 'on');
        fname = strcat("objective_kappa1.3_lamda" , num2str(aplot), ".png") ;
        
        %fname = strcat("objective_kappa1.3_lamda" , num2str(aplot), ".csv") ;
        
        %datasave = cat(1, gamma, y_km ./ y_rd, yamean(yaplot(k)) ./ y_rd, ya(yaplot(k)) ./ y_rd );
        %csvwrite(fname, datasave);
        saveas(gcf, fname);
    end

%saveas(gcf,'fcost_kappa1.3.jpg');




%p5.Marker = 'o';
%hold on;

%p9= plot(gamma, (ya(10, :)), 'LineWidth', 2); %gbr/rnd
%p9.Marker = 'd';
%hold on;

%p10= plot(gamma, (ya(11, :)), 'LineWidth', 2); %gbr/rnd
%p10.Marker = 's';
%hold on;

%title ("f cost, #clusters = 100, kappa = 1.5");

%legend ("a=0.0", "a=.5", "a=.9", "a=1");

