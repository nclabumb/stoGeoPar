%EC, geocost, EC_mean, geocost_mean column mapping
%kappa = 1, gamma = 2, a = 3, rnd = 4, gbr/rnd = 5

%EC_KM_MT column mapping
%kappa = 1, gamma = 2, a = 3, km = 4, mt = 5


EC = csvread("EC_rd_cost_M100.csv"); % kappa(1), gamma (2), 
geocost = csvread("geo_rd_cost_M100.csv");

EC_km_mt = csvread("EC_KM_MT_cost_M100.csv");
geocost_km_mt = csvread("geo_KM_MT_cost_M100.csv");


%X => a
%Y => ec + geo cost



a = 0:0.1:1;

row_start = 56 ; %kappa=1.3
num_row_gap = 10;

max_geo = 670470; %kmean_cost_1cluster % max(max(geocost(1:7, :))); % to scale

num_gamma = 5;
y_km = zeros(1,num_gamma);
y_mt = zeros(1,num_gamma);

for i = 1:num_gamma
    
    y_km(i) = EC_km_mt(row_start + (i -1) * num_row_gap + (i-1),4) + ...
                geocost_km_mt(row_start + (i -1) * num_row_gap + (i-1),4)/max_geo;
    y_mt(i) = EC_km_mt(row_start + (i -1) * num_row_gap + (i-1),5)+ ...
                geocost_km_mt(row_start + (i -1) * num_row_gap + (i-1),5)/max_geo;
    
end


g1 = EC(row_start                       : row_start +     num_row_gap,     5); % gamma = .1
g3 = EC(row_start +     num_row_gap + 1 : row_start + 2 * num_row_gap + 1, 5); % gamma = .3
g5 = EC(row_start + 2 * num_row_gap + 2 : row_start + 3 * num_row_gap + 2, 5); % gamma = .5
g7 = EC(row_start + 3 * num_row_gap + 3 : row_start + 4 * num_row_gap + 3, 5); % gamma = .7
g9 = EC(row_start + 4 * num_row_gap + 4 : row_start + 5 * num_row_gap + 4, 5); % gamma = .9


g1 = g1 + geocost(row_start                       : row_start +     num_row_gap,     5)/max_geo; % gamma = .1
g3 = g3 + geocost(row_start +     num_row_gap + 1 : row_start + 2 * num_row_gap + 1, 5)/max_geo; % gamma = .3
g5 = g5 + geocost(row_start + 2 * num_row_gap + 2 : row_start + 3 * num_row_gap + 2, 5)/max_geo; % gamma = .5
g7 = g7 + geocost(row_start + 3 * num_row_gap + 3 : row_start + 4 * num_row_gap + 3, 5)/max_geo; % gamma = .7
g9 = g9 + geocost(row_start + 4 * num_row_gap + 4 : row_start + 5 * num_row_gap + 4, 5)/max_geo; % gamma = .9


%aplot = [1 2 4 6 8 10 11]; % 0, .1, .3, .5, .7, .9, 1
% ya mapping 
%row 1 = a0, 2 = a0.1, 3 = a0.2, .... 10 = a0.9, 11 = a1

gamma = 0.1:0.2:0.9;
ya = [g1, g3, g5, g7, g9];

yaplot = [6 2 10];
lg = {'BR/Gauss a = 0', 'BR/Gauss a = .1', 'BR/Gauss a = .2', 'BR/Gauss a = .3', 'BR/Gauss a = .4', ...
    'BR/Gauss a = .5', 'BR/Gauss a = .6', 'BR/Gauss a = .7', 'BR/Gauss a = .8', 'BR/Gauss a = .9', ...
    'BR/Gauss a = 1'};
marker = '*+odsx.ph^v';%{'*', '+', 'o', 'diamond', 'square', 'x', '.', 'pentagram', 'hexagram', '^', 'v' };
c = [1 0 0
    0 1 0
    1 1 0
    0 0.4470 0.7410
    0.8500 0.3250 0.0980
    0.9290 0.6940 0.1250
    0.4940 0.1840 0.5560
    0.4660 0.6740 0.1880
    0.3010 0.7450 0.9330
    0.6350 0.0780 0.1840];
num_line = 3;

figure;
lgshow = { 'kMean','METIS'};

pkm= plot(gamma, y_km, 'LineWidth', 2, 'Color', [0 0 1]); %gbr/rnd
pkm.Marker = '^';
hold on;    

pmt= plot(gamma, y_mt, 'LineWidth', 2, 'Color', [1 0 1]); %gbr/rnd
pmt.Marker = 'v';
hold on;

for i = 1:num_line
    p= plot(gamma, ya(yaplot(i), :), 'LineWidth', 2); %gbr/rnd
    p.Marker = marker(1,i);
    p.Color = c(i, :);
    lgshow(i + 2) = lg(yaplot(i));
    hold on;

end

legend (lgshow);
xlabel("Gamma");
ylabel ("Empirical Cost + Geo Cost");

saveas(gcf,'ec_plusgeocost_kappa1.3.jpg');




%p5.Marker = 'o';
%hold on;

%p9= plot(gamma, (ya(10, :)), 'LineWidth', 2); %gbr/rnd
%p9.Marker = 'd';
%hold on;

%p10= plot(gamma, (ya(11, :)), 'LineWidth', 2); %gbr/rnd
%p10.Marker = 's';
%hold on;

%title ("f cost, #clusters = 100, kappa = 1.5");

%legend ("a=0.0", "a=.5", "a=.9", "a=1");

