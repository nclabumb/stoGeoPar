%EC, geocost, EC_mean, geocost_mean column mapping
%kappa = 1, gamma = 2, a = 3, rnd = 4, gbr/rnd = 5

%EC_KM_MT column mapping
%kappa = 1, gamma = 2, a = 3, km = 4, mt = 5


EC = csvread("EC_rd_cost_allkappa_M100.csv"); % kappa(1), gamma (2), 
geocost = csvread("geo_rd_cost_allkappa_M100.csv");

EC_mean = csvread("EC_rd_BRMeancost_allkappa_M100.csv");
geocost_mean = csvread("geo_rd_BRmean_cost_allkappa_M100.csv");

EC_km_mt = csvread("EC_KM_MT_cost_M100.csv");
geocost_km_mt = csvread("geo_KM_MT_cost_M100.csv");

%X => geocost
%Y => ECcost

% scatter on kmean, metis, rnd, gbr/rnd, gbr/rnd without standard
% derivation 



%rows = [1:11] ; %kappa=0.7, gamma=.1,
%rows = [23:33] ; %kappa=0.7, gamma=.5,
%rows = [45:55] ; %kappa=0.7, gamma=.9,

%rows = [56:66] ; %kappa=1, gamma=.1,
%rows = [78:88] ; %kappa=1, gamma=.5,
%rows = [100:110] ; %kappa=1, gamma=.9,

%rows = [111:121] ; %kappa=1.3, gamma=.1,
%rows = [133:143] ; %kappa=1.3, gamma=.5,
rows = [155:165] ; %kappa=1.3, gamma=.9,


max_geo = 670470; %kmean_cost_1cluster % max(max(geocost(1:7, :))); % to scale

x_rd = geocost(rows, 4)/max_geo;
x_rdplus = geocost(rows, 5)/max_geo;

x_rd_mean = geocost_mean(rows, 4)/max_geo;
x_rdplus_mean = geocost_mean(rows, 5)/max_geo;


x_km = geocost_km_mt(rows, 4)/max_geo;
x_mt = geocost(rows, 4)/max_geo; %rand

y_rd = EC(rows, 4);
y_rdplus = EC(rows, 5);

y_rd_mean = EC_mean(rows, 4);
y_rdplus_mean = EC_mean(rows, 5);

y_km = EC_km_mt(rows,4);
y_mt = EC(rows,4); %rand

str = {'0', '.1', '.2', '.3', '.4', '.5', '.6', '.7', '.8', '.9', '1'};

figure('Renderer', 'painters', 'Position', [10 10 900 600]);
scatter(log10(x_km), log10(y_km), 200, 'filled', 'd'); % 'MarkerFaceColor', [0 0 1]kmean
hold on;

%scatter((x_mt), (y_mt), 50, 'filled'); %rand , 'MarkerFaceColor', [1 0 1]
%hold on;

scatter(log10(x_rd), log10(y_rd), 200, 'filled', 's'); % rnd
hold on;


%scatter(log(x_rd_mean), log(y_rd_mean), 50, 'filled'); %rnd_mean
%hold on;


%scatter(log(x_rdplus), log(y_rdplus), 50, 'filled'); %gbr/rnd
p1= plot(log10(x_rdplus), log10(y_rdplus), 'LineWidth', 2); %gbr/rnd
p1.Marker = '*';
p1.MarkerSize = 20;
text(log10(x_rdplus), log10(y_rdplus), str);
hold on;

%scatter(log(x_rdplus_mean),log(y_rdplus_mean), 50, 'filled'); %gbr/rnd_mean

p2 = plot(log10(x_rdplus_mean),log10(y_rdplus_mean), 'LineWidth', 2); %gbr/rnd_mean
p2.Marker = '+';
p2.MarkerSize = 20;
%text((x_rdplus_mean), (y_rdplus_mean), str);

%hold on;



%scatter(x_GBR_KM, y_GBR_KM, 15, 'filled');
%plot(x_GBR_KM, y_GBR_KM, 'LineWidth', 2);
%hold on;
%scatter(x_GBR_MT, y_GBR_MT, 15, 'filled');
%plot(x_GBR_MT, y_GBR_MT, 'LineWidth', 2);
%xlim([0 2]);


%title ("EC & Geo cost, #clusters = 100, kappa = 1.5, gamma = 0.9, a = [.1 -> .9]");

%legend ("Kmean", "METIS", "RND", "rndMEAN", "GBR/RND", "GBR/rndMEAN");
%legend ("BR/Gauss", "BR/Mean");

xlabel("log10(Geo Spread)", 'FontWeight', 'bold');
ylabel ("log10(Backhaul Cost)", 'FontWeight', 'bold');
legend ('kMeans','Rand', 'BR/Gauss', 'BR/Mean', 'Location', 'Best');
xlim([-2.5 0.5]);
%        ylim([0 inf]);
        %axis([0.1 0.9 0 0.9]);
        set(gca,'FontSize',30, 'box', 'on');
saveas(gcf,'backhaul_geospread_kappa1.3_gamma0.9.png');


