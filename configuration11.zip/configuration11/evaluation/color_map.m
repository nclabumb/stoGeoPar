%kmean

points = csvread("../input/topology.xy");
%disp(size(points));
k = 100;
%[ind, C] = kmeans(points, k);
%ind = ind - 1;
%ind = csvread("z_GBRPartitionByGGW_D5_N13269_M30_kappa1.5_gamma0.3.csv"); %csvread("z_GBRPartitionByGGW_D6_N13269_M30_kappa1.5_gamma0.9.csv");
%ind = csvread("z_GBRPartitionByGGW_D5_N13269_M25_kappa1.5_gamma0.3.csv");
%ind = csvread("../output/z_metis_LS_N13269_M100_kappa1.5_gamma0.1_a0.9.csv");
ind = csvread("z_rd_LS_N13269_M100_kappa1_gamma0.5_a0.csv");

%ind = csvread("../input/z_kmean_K100");
figure('Renderer', 'painters', 'Position', [10 10 700 600]);

for i=1:k
    %plot(points(ind == i, 1), points(ind == i, 2),'.', 'MarkerSize', 8);
    %scatter(points(ind == i-1, 1), points(ind == i-1, 2), 15, 'filled', 'MarkerFaceColor', c(i, :));
    scatter(points(ind == i-1, 1), points(ind == i-1, 2),15, 'filled');
    
    hold on;
    %plot(points(ind == 2, 1), points(ind == 2, 2),'b.', 'MarkerSize', 5);
end

xlabel("X", 'FontSize', 50, 'FontWeight', 'bold');
ylabel ('Y','FontSize',50,'FontWeight', 'bold');
set(gca, 'FontSize', 20, 'box', 'on');

%saveas(gcf, "colormap_z_kmean_K100.png");

saveas(gcf, "colormap_z_rd_LS_N13269_M100_kappa1_gamma0.5_a0.png");
%title( "../output/z_metis_LS_N13269_M100_kappa1.5_gamma0.1_a0.9.csv");
%csvwrite("../input/z_kmean_K300", ind);
%disp(max(ind));

%{
c = [0 0 0
    0 0 1
    0 1 0
    0 1 1
    1 0 0
    1 0 1
    1 1 0
    0 0.4470 0.7410
    0.8500 0.3250 0.0980
    0.9290 0.6940 0.1250
    0.4940 0.1840 0.5560
    0.4660 0.6740 0.1880
    0.3010 0.7450 0.9330
    0.6350 0.0780 0.1840
    0 0 0.5
    0 0.5 0
    0 0.5 0.5
    0.5 0 0
    0.5 0 0.5
    0.5 0.5 0
    0.5 0.5 0.5
    0 0.25 0.25
    0 0.75 0
    0 0.75 0.75
    0.75 0 0
    0.75 0 0.75
    0.75 0.75 0
    0.75 0.75 0.75
    0.5 0.5 0.1
    0.75 1 0
    ];

%}