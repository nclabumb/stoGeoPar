
%con column mapping
%kappa = 1, gamma = 2, num of iterations of BR/Gauss


con = csvread("move_M100.csv");


%X => gamma
%Y => num of iterations
% consider all kappa, all gamma, fix a = 0.5

row_start = 6 ; %kappa=1.3
num_row_gap = 10;


num_bar = 15; % 3 kappa x 5 gamma
y = zeros(1,num_bar);

for i = 1:num_bar
    
    y(i) = con(row_start + (i - 1) * num_row_gap + (i-1),4);
    
end

ybar = zeros(3,5);
for i = 1:3
    for j = 1:5
        ind = (i - 1) * 5 + j;
        ybar(i,j) = y(ind);
    end
end
x = categorical({'1.0', '1.3', '1.5'});
figure;
bar(x, ybar);
legend('gamma=.1', 'gamma=.3', 'gamma=.5','gamma=.7','gamma=.9');
xlabel('Kappa');
ylabel('Number of movings');
saveas(gca, 'move_a0.5.jpg');