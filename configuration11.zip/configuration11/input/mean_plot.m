meandata = csvread("TimeVaryingWeights_packets_AllBS.MeanSD");

figure('Renderer', 'painters', 'Position', [10 10 900 600]);
n = size(meandata,1);
x = 1:1:n;

[yprime, iy] = sort(meandata(:,1));

y = meandata(:,2) ./ meandata(:,1);

 

%y = sort(meandata(:,1));
%s = scatter(y(iy), yprime, 3, 'filled');
%plot(x, log10(yprime), 'LineWidth', 2);
s = scatter(x, log10(y(iy)), 3, 'filled');

xlabel("Cell", 'FontSize', 50, 'FontWeight', 'bold');
ylabel ('log10(Coefficient of Variation)','FontSize',50,'FontWeight', 'bold');
%ylabel ('log10(Workload Mean)','FontSize',50,'FontWeight', 'bold');
set(gca, 'FontSize', 30, 'box', 'on');
%saveas(gcf, 'mean.png');
saveas(gcf, 'CoefficientVariation.png');